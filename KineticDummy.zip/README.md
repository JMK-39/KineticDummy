# KineticDummy

KineticCore companion module containing the training dummy, damage statistics, Curios dummy equipment, Jade integration and related client displays.

Configuration files intentionally remain at:
- `config/kineticcore/dummy_server.toml`
- `config/kineticcore/dummy_client.toml`

The module requires KineticCore and Curios. Jade is optional at runtime. Only the two configuration file paths remain under config/kineticcore; registry IDs and player runtime data use kineticdummy.


Client config registration is owned entirely by KineticDummy. `config/kineticcore/dummy_client.toml` is no longer registered by KineticCore.
