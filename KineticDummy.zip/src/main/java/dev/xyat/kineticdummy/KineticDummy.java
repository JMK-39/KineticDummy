package dev.xyat.kineticdummy;

import com.mojang.logging.LogUtils;
import dev.xyat.kineticdummy.dummy.DummyInit;
import dev.xyat.kineticdummy.dummy.Network.DummyNetwork;
import dev.xyat.kineticdummy.dummy.command.DummyCommandExtension;
import dev.xyat.kineticdummy.dummy.config.DummyConfig;
import dev.xyat.kineticdummy.client.KineticDummyClientBootstrap;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(KineticDummy.MODID)
public final class KineticDummy {
    public static final String MODID = "kineticdummy";
    public static final Logger LOGGER = LogUtils.getLogger();

    public KineticDummy(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();

        DummyConfig.register(context);
        DummyInit.register(modEventBus);
        DummyNetwork.register();
        DummyCommandExtension.install();

        DistExecutor.unsafeRunWhenOn(
                Dist.CLIENT,
                () -> () -> KineticDummyClientBootstrap.register(context)
        );
    }
}
